/*
 * opngcore/version.h
 * Version info.
 *
 * Copyright (C) 2011 Cosmin Truta.
 *
 * This software is distributed under the zlib license.
 * Please see the accompanying LICENSE file.
 */

#ifndef OPNGCORE_VERSION_H
#define OPNGCORE_VERSION_H


#define OPNGLIB_VERSION "@OPNGLIB_VERSION@"


#endif  /* OPNGCORE_VERSION_H */
