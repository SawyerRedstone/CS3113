Name: pnmio
Summary: Simple I/O interface to the PNM image file format
Author: Cosmin Truta
Version: 0.3
License: zlib
