The Biped Dragon Sprite Sheet

This character has been made by Marco Giorgini (info@marcogiorgini.com / www.marcogiorgini.com) and it's released under this CC licence: http://creativecommons.org/licenses/by/3.0/ [Attribution 3.0]

If you use it in your game, please let me know :-)
